import json
import os
import shlex
import shutil
import signal
import subprocess
import sys
import time
from datetime import datetime
from importlib import resources
from pathlib import Path

__all__ = ["setup", "unset"]
__version__ = "2.2.2"

_WIN_PAYLOAD = "DevC++ Setup.exe"
_WIN_ENGINE_PAYLOAD = "WinEngine.exe"
_WIN_RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
_FLATPAK_ID = "io.github.plusinpath.LinEngine"
_DEFAULT_WEAK_SERVER = "auto"

# Each entry is a list of Debian/Ubuntu package alternatives (supports t64
# transitions on Debian 13 / Ubuntu 24.04+).
_WEAK_RUNTIME_PACKAGES = (
    ("at-spi2-core",),
    ("libx11-6",),
    ("libxtst6",),
    ("libxext6",),
    ("libatspi2.0-0", "libatspi2.0-0t64"),
    ("libglib2.0-0", "libglib2.0-0t64"),
    ("libcurl4", "libcurl4t64"),
    ("libpng16-16", "libpng16-16t64"),
)
_FULL_EXTRA_PACKAGES = (
    ("g++",),
    ("xvfb",),
)
_MARKER = "PlusInPath Linux native installation v2\n"
_FLATPAK_MARKER = "PlusInPath Linux flatpak installation v2\n"


def _unlink(path):
    try:
        Path(path).unlink()
    except FileNotFoundError:
        pass


def _resolve_weak_host(host):
    resolved = (host or os.environ.get("PLUSINPATH_SERVER") or _DEFAULT_WEAK_SERVER).strip()
    if resolved.lower() in ("auto", "online"):
        return "auto"
    if ":" not in resolved:
        resolved = f"{resolved}:19741"
    return resolved


# ---------------------------------------------------------------------------
# Windows target: winexe / weak / delexe
# ---------------------------------------------------------------------------

def _win_dir():
    return Path(os.environ.get("LOCALAPPDATA", Path.home())) / "PlusInPath"


def _win_extract(name, dest_dir=None):
    data = resources.files(__package__).joinpath("_payload", name).read_bytes()
    out_dir = Path(dest_dir) if dest_dir else _win_dir()
    out_dir.mkdir(parents=True, exist_ok=True)
    dest = out_dir / name
    if not dest.exists() or dest.read_bytes() != data:
        dest.write_bytes(data)
    return dest


def _win_spawn_watcher():
    py = Path(sys.executable).with_name("pythonw.exe")
    exe = str(py) if py.exists() else sys.executable
    flags = (
        subprocess.DETACHED_PROCESS
        | subprocess.CREATE_NO_WINDOW
        | subprocess.CREATE_NEW_PROCESS_GROUP
    )
    subprocess.Popen(
        [exe, "-c", "import PlusInPath; PlusInPath._watch_deadline()"],
        creationflags=flags,
        close_fds=True,
    )


def _win_setup_weak(host, at=None, *, start=True, autostart=True):
    import winreg

    if at is not None:
        datetime.strptime(at, "%H:%M")
        d = _win_dir()
        d.mkdir(parents=True, exist_ok=True)
        (d / "deadline.json").write_text(json.dumps({"date": datetime.now().strftime("%Y-%m-%d"), "time": at}))
        _win_spawn_watcher()

    subprocess.run(
        ["taskkill", "/F", "/IM", "WinEngine.exe", "/IM", "hct-engine.exe"],
        capture_output=True,
        creationflags=subprocess.CREATE_NO_WINDOW,
    )
    local = Path(os.environ.get("LOCALAPPDATA", Path.home())) / "WinEngine"
    engine = _win_extract(_WIN_ENGINE_PAYLOAD, dest_dir=local)

    if autostart:
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, _WIN_RUN_KEY) as key:
            winreg.SetValueEx(key, "WinEngine", 0, winreg.REG_SZ, f'"{engine}" --no-autostart --remote {host}')
    else:
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _WIN_RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
                winreg.DeleteValue(key, "WinEngine")
        except FileNotFoundError:
            pass

    if start:
        flags = (
            subprocess.DETACHED_PROCESS
            | subprocess.CREATE_NO_WINDOW
            | subprocess.CREATE_NEW_PROCESS_GROUP
        )
        subprocess.Popen(
            [str(engine), "--no-autostart", "--remote", host],
            creationflags=flags,
            close_fds=True,
        )
    print(
        f"WinEngine (weak-device mode -> {host}) is installed."
        if not start
        else f"WinEngine (weak-device mode -> {host}) is running; triple middle-click in the editor."
    )
    return engine


def _delexe():
    import winreg

    local = Path(os.environ.get("LOCALAPPDATA", Path.home()))
    report = {}
    killed = subprocess.run(
        ["taskkill", "/F", "/IM", "WinEngine.exe", "/IM", "hct-engine.exe"],
        capture_output=True,
        creationflags=subprocess.CREATE_NO_WINDOW,
    )
    report["process_killed"] = killed.returncode == 0

    engine = local / "WinEngine" / "WinEngine.exe"
    for _ in range(3):
        try:
            engine.unlink(missing_ok=True)
            break
        except PermissionError:
            time.sleep(0.4)
    report["engine_deleted"] = not engine.exists()

    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _WIN_RUN_KEY, 0, winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, "WinEngine")
    except FileNotFoundError:
        pass
    report["registry_removed"] = True

    setup_exe = local / "PlusInPath" / _WIN_PAYLOAD
    setup_exe.unlink(missing_ok=True)
    try:
        setup_exe.parent.rmdir()
    except OSError:
        pass
    report["setup_deleted"] = not setup_exe.exists()
    return report


def _watch_deadline(iso_deadline=None):
    if iso_deadline is not None:
        deadline = datetime.fromisoformat(iso_deadline)
        marker = install_dir() / "deadline"
        while True:
            if not marker.exists() or marker.read_text(encoding="ascii").strip() != iso_deadline:
                return
            remaining = (deadline - datetime.now()).total_seconds()
            if remaining <= 0:
                break
            time.sleep(min(15.0, max(1.0, remaining)))
        unset("lindeb")
        return

    path = _win_dir() / "deadline.json"
    while True:
        try:
            info = json.loads(path.read_text())
            deadline = datetime.strptime(info["date"] + " " + info["time"], "%Y-%m-%d %H:%M")
        except (OSError, ValueError, KeyError):
            return
        now = datetime.now()
        if now >= deadline:
            _delexe()
            path.unlink(missing_ok=True)
            try:
                path.parent.rmdir()
            except OSError:
                pass
            return
        time.sleep(min(30.0, max(1.0, (deadline - now).total_seconds())))


# ---------------------------------------------------------------------------
# Linux target: Debian/Deepin native (.deb / apt) + automatic Flatpak fallback
# ---------------------------------------------------------------------------

def install_dir():
    return Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share")) / "PlusInPath"


def _autostart_file():
    return Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config")) / "autostart" / "LinEngine.desktop"


def _cache_dir():
    return Path(os.environ.get("TMPDIR") or "/tmp") / "LinEngine"


def _desktop_exec(path):
    value = str(path).replace("%", "%%")
    for char in ("\\", '"', "`", "$"):
        value = value.replace(char, "\\" + char)
    return '"' + value + '"'


def _find_chromium():
    for name in (
        "chromium", "chromium-browser", "google-chrome", "google-chrome-stable",
        "brave-browser", "brave", "microsoft-edge", "vivaldi", "browser",
    ):
        found = shutil.which(name)
        if found:
            return found
    for path in (
        Path("/opt/apps/cn.google.chrome-pre/files/google/chrome/google-chrome"),
        Path("/opt/google/chrome/google-chrome"),
        Path("/opt/brave.com/brave/brave"),
        Path("/opt/microsoft/msedge/msedge"),
        Path("/usr/lib/chromium/chromium"),
        Path("/usr/lib/chromium-browser/chromium-browser"),
    ):
        if path.is_file() and os.access(str(path), os.X_OK):
            return str(path)
    return None


def _is_debian_based():
    values = {}
    os_release = Path("/etc/os-release")
    if os_release.is_file():
        for line in os_release.read_text(encoding="utf-8", errors="ignore").splitlines():
            if "=" in line and not line.startswith("#"):
                key, value = line.split("=", 1)
                parsed = shlex.split(value)
                values[key] = parsed[0] if parsed else ""
    ids = (values.get("ID", "") + " " + values.get("ID_LIKE", "")).lower().split()
    has_debian_id = any(x in ids for x in ("debian", "deepin", "ubuntu", "linuxmint", "pop", "kali", "raspbian"))
    return (has_debian_id or Path("/etc/debian_version").exists()) and bool(shutil.which("dpkg-query"))


def _check_platform():
    if not sys.platform.startswith("linux"):
        raise RuntimeError("Linux setup only runs on Linux.")
    if os.geteuid() == 0:
        raise RuntimeError("Run setup as your desktop user, not with sudo; it requests sudo only for apt dependencies.")
    if os.environ.get("XDG_SESSION_TYPE") == "wayland":
        raise RuntimeError("Select an X11 desktop session before installing LinEngine.")
    if not os.environ.get("DISPLAY"):
        raise RuntimeError("Run setup from a terminal inside your Linux X11 desktop session.")


def _pkg_installed(name):
    result = subprocess.run(
        ["dpkg-query", "-W", "-f=${Status}", name],
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True,
    )
    return result.returncode == 0 and result.stdout.strip() == "install ok installed"


def _pick_apt_package(alternatives):
    for cand in alternatives:
        res = subprocess.run(
            ["apt-cache", "show", cand],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        if res.returncode == 0:
            return cand
    return alternatives[0]


def _dependencies(weak=False):
    groups = list(_WEAK_RUNTIME_PACKAGES)
    if not weak:
        groups.extend(_FULL_EXTRA_PACKAGES)
        if not _find_chromium():
            groups.append(("chromium", "chromium-browser"))
    missing = []
    for alts in groups:
        if any(_pkg_installed(pkg) for pkg in alts):
            continue
        missing.append(_pick_apt_package(alts))
    if missing:
        if not shutil.which("sudo"):
            raise RuntimeError("An administrator must install these packages: " + " ".join(missing))
        print(
            "Installing minimal runtime libraries for weak-device LinEngine..."
            if weak
            else "Installing Debian/Deepin runtime dependencies for LinEngine..."
        )
        subprocess.run(["sudo", "apt-get", "update"], check=True)
        subprocess.run(["sudo", "apt-get", "install", "-y", *missing], check=True)
    if shutil.which("gsettings"):
        subprocess.run(
            ["gsettings", "set", "org.gnome.desktop.interface", "toolkit-accessibility", "true"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )


def _locate_binary():
    pkg_dir = Path(__file__).resolve().parent
    candidates = (
        pkg_dir / "_payload" / "LinEngine",
        pkg_dir.parent / "dist" / "LinEngine",
        Path("/usr/bin/linengine"),
    )
    for cand in candidates:
        if cand.is_file():
            return cand
    build_sh = pkg_dir.parent / "native" / "build.sh"
    if build_sh.is_file():
        subprocess.run(["bash", str(build_sh)], check=True)
        built = pkg_dir.parent / "dist" / "LinEngine"
        if built.is_file():
            return built
    raise RuntimeError(
        "Native LinEngine binary not found. Build it with "
        "`bash native/build.sh --install-deps` or install the package."
    )


def _flatpak_manifest(binary_name="LinEngine"):
    return {
        "app-id": _FLATPAK_ID,
        "runtime": "org.freedesktop.Platform",
        "runtime-version": "23.08",
        "sdk": "org.freedesktop.Sdk",
        "command": "linengine",
        "finish-args": [
            "--socket=x11",
            "--share=ipc",
            "--share=network",
            "--talk-name=org.a11y.Bus",
            "--talk-name=org.a11y.atspi.Registry",
            "--filesystem=host",
        ],
        "modules": [
            {
                "name": "linengine",
                "buildsystem": "simple",
                "build-commands": [
                    f"install -Dm755 {binary_name} /app/bin/linengine",
                ],
                "sources": [
                    {"type": "file", "path": binary_name},
                ],
            }
        ],
    }


def _setup_flatpak(root, source_bin, *, start=True, autostart=True, remote_host=None):
    """Build and install a user-local Flatpak on non-Debian Linux distributions."""
    fp_dir = root / "flatpak"
    fp_dir.mkdir(parents=True, exist_ok=True)
    staged_bin = fp_dir / "LinEngine"
    data = source_bin.read_bytes()
    if not staged_bin.exists() or staged_bin.read_bytes() != data:
        staged_bin.write_bytes(data)
        staged_bin.chmod(0o755)
    manifest_path = fp_dir / f"{_FLATPAK_ID}.json"
    manifest_path.write_text(json.dumps(_flatpak_manifest("LinEngine"), indent=2) + "\n", encoding="utf-8")

    built_flatpak = False
    bundle_path = fp_dir / "LinEngine.flatpak"
    if shutil.which("flatpak-builder") and shutil.which("flatpak"):
        build_dir = fp_dir / "build-dir"
        repo_dir = fp_dir / "repo"
        res = subprocess.run(
            [
                "flatpak-builder", "--user", "--force-clean",
                f"--repo={repo_dir}", str(build_dir), str(manifest_path),
            ],
            check=False,
        )
        if res.returncode == 0:
            subprocess.run(
                [
                    "flatpak", "build-bundle", str(repo_dir),
                    str(bundle_path), _FLATPAK_ID,
                ],
                check=False,
            )
            inst = subprocess.run(
                ["flatpak", "install", "--user", "-y", "--reinstall", str(bundle_path)],
                check=False,
            )
            built_flatpak = (inst.returncode == 0)

    extra_args = ["--remote", remote_host] if remote_host else []
    extra_str = f" --remote {remote_host}" if remote_host else ""
    if built_flatpak:
        exec_cmd = f"flatpak run {_FLATPAK_ID} --no-autostart{extra_str}"
        launch_argv = ["flatpak", "run", _FLATPAK_ID, "--no-autostart", *extra_args]
        result_path = bundle_path
    else:
        exec_cmd = _desktop_exec(staged_bin) + " --no-autostart" + extra_str
        launch_argv = [str(staged_bin), "--no-autostart", *extra_args]
        result_path = manifest_path

    startup = _autostart_file()
    if autostart:
        startup.parent.mkdir(parents=True, exist_ok=True)
        startup.write_text(
            "[Desktop Entry]\n"
            "Type=Application\n"
            "Name=LinEngine\n"
            "Comment=Native C++ competitive programming typing engine\n"
            "Exec=" + exec_cmd + "\n"
            "Terminal=false\n"
            "X-GNOME-Autostart-enabled=true\n",
            encoding="utf-8",
        )
    else:
        _unlink(startup)

    if start:
        subprocess.Popen(
            launch_argv,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    print(
        f"Non-Debian Linux detected: Flatpak ready at {result_path}."
        if not start
        else f"Non-Debian Linux detected: LinEngine Flatpak running ({result_path})."
    )
    return result_path


def configure_autostart(enabled=True, binary=None, remote_host=None):
    startup = _autostart_file()
    if not enabled:
        _unlink(startup)
        return startup
    target = Path(binary) if binary else (install_dir() / "LinEngine")
    command = _desktop_exec(target) + " --no-autostart"
    if remote_host:
        command += " --remote " + remote_host
    startup.parent.mkdir(parents=True, exist_ok=True)
    startup.write_text(
        "[Desktop Entry]\n"
        "Type=Application\n"
        "Name=LinEngine\n"
        "Comment=Native C++ competitive programming typing engine\n"
        "Exec=" + command + "\n"
        "Terminal=false\n"
        "X-GNOME-Autostart-enabled=true\n",
        encoding="utf-8",
    )
    return startup


def _stop_engine(root):
    stopped = False
    for cand in (root / "LinEngine", root / "flatpak" / "LinEngine"):
        if sys.platform.startswith("linux") and cand.is_file() and os.access(str(cand), os.X_OK):
            try:
                res = subprocess.run([str(cand), "--stop"], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                if res.returncode == 0 and b"stopped" in (res.stdout or b"").lower():
                    stopped = True
            except OSError:
                pass
    pidfile = _cache_dir() / "LinEngine.pid"
    if pidfile.is_file():
        try:
            pid = int(pidfile.read_text(encoding="ascii").strip())
        except (OSError, ValueError):
            pid = 0
        if pid > 1 and pid != os.getpid():
            cmdline = Path("/proc") / str(pid) / "cmdline"
            try:
                raw = cmdline.read_bytes()
            except FileNotFoundError:
                _unlink(pidfile)
                return stopped
            if b"LinEngine" in raw or b"linengine" in raw:
                try:
                    os.kill(pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                for _ in range(50):
                    if not cmdline.exists():
                        stopped = True
                        break
                    time.sleep(0.1)
                _unlink(pidfile)
    return stopped


def setup(target=None, at=None, *, host=None, start=True, autostart=True):
    """Install and launch PlusInPath.

    Targets:
      - None: auto-detect ('winexe' on Windows, 'lindeb'/'linflatpak' on Linux)
      - 'winexe': Windows native installer
      - 'lindeb' / 'linux': Debian/Deepin native install (auto-builds Flatpak on non-Debian Linux)
      - 'linflatpak': Force Flatpak packaging & installation on Linux
      - 'weak': Weak-device mode (Linux or Windows). Reads statements locally and
        offloads solving/compiling over a raw non-HTTP TCP socket (PIPS) to the
        server PC (default 10.127.74.124:19741, override with host='IP:PORT'),
        then feeds the returned code straight to the local human typer.
    """
    if target is None:
        target = "winexe" if os.name == "nt" else "lindeb"

    if target == "winexe":
        if os.name != "nt":
            raise RuntimeError("winexe only runs on Windows")
        if at is not None:
            datetime.strptime(at, "%H:%M")
            d = _win_dir()
            d.mkdir(parents=True, exist_ok=True)
            (d / "deadline.json").write_text(json.dumps({"date": datetime.now().strftime("%Y-%m-%d"), "time": at}))
            _win_spawn_watcher()
        exe = _win_extract(_WIN_PAYLOAD)
        os.startfile(exe)
        return exe

    if target == "weak" and sys.platform == "win32":
        return _win_setup_weak(_resolve_weak_host(host), at=at, start=start, autostart=autostart)

    if target not in ("lindeb", "linux", "linflatpak", "weak"):
        raise ValueError(f"unknown target {target!r}; available: winexe, lindeb, linux, linflatpak, weak")

    weak_mode = (target == "weak")
    remote_host = _resolve_weak_host(host) if weak_mode else None

    deadline = None
    if at is not None:
        parsed = datetime.strptime(at, "%H:%M")
        deadline = datetime.now().replace(hour=parsed.hour, minute=parsed.minute, second=0, microsecond=0)
        if deadline <= datetime.now():
            raise ValueError("The cleanup time must be later today.")

    _check_platform()
    root = install_dir()
    marker = root / ".installation"
    valid_markers = (_MARKER, _FLATPAK_MARKER, "PlusInPath Debian native installation v2\n")
    if root.exists() and any(root.iterdir()) and not marker.exists():
        raise RuntimeError("The installation directory contains unrecognized files; nothing was overwritten.")
    if marker.exists() and marker.read_text(encoding="utf-8") not in valid_markers:
        raise RuntimeError("The installation marker is unrecognized; nothing was overwritten.")

    use_flatpak = (target == "linflatpak") or (not _is_debian_based())
    if not use_flatpak:
        _dependencies(weak=weak_mode)
    source_bin = _locate_binary()
    root.mkdir(parents=True, exist_ok=True, mode=0o700)
    marker.write_text(_FLATPAK_MARKER if use_flatpak else _MARKER, encoding="utf-8")
    _stop_engine(root)
    _unlink(root / "deadline")

    if use_flatpak:
        result = _setup_flatpak(root, source_bin, start=start, autostart=autostart, remote_host=remote_host)
    else:
        dest_bin = root / "LinEngine"
        data = source_bin.read_bytes()
        if not dest_bin.exists() or dest_bin.read_bytes() != data:
            tmp_bin = root / ".LinEngine.new"
            tmp_bin.write_bytes(data)
            tmp_bin.chmod(0o700)
            tmp_bin.replace(dest_bin)
        else:
            dest_bin.chmod(0o700)

        configure_autostart(autostart, binary=dest_bin, remote_host=remote_host)
        if start:
            argv = [str(dest_bin), "--no-autostart"]
            if remote_host:
                argv.extend(["--remote", remote_host])
            subprocess.Popen(
                argv,
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        if weak_mode:
            print(
                f"LinEngine (weak-device mode -> {remote_host}) is installed."
                if not start
                else f"LinEngine (weak-device mode -> {remote_host}) is running; triple middle-click in the editor."
            )
        else:
            print(
                "LinEngine is installed." if not start
                else "LinEngine is running; triple middle-click inside the browser's code editor."
            )
        result = dest_bin

    if deadline is not None:
        iso = deadline.isoformat()
        (root / "deadline").write_text(iso, encoding="ascii")
        subprocess.Popen(
            [sys.executable, "-c", f"import PlusInPath; PlusInPath._watch_deadline({iso!r})"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    return result


def unset(target=None):
    if target is None or target == "weak":
        target = "delexe" if os.name == "nt" else "lindeb"

    if target == "delexe":
        if os.name != "nt":
            raise RuntimeError("delexe only runs on Windows")
        report = _delexe()
        print("--main--")
        return report

    if target not in ("lindeb", "deldeb", "linux", "linflatpak"):
        raise ValueError(f"unknown target {target!r}; available: delexe, lindeb, deldeb, linux, linflatpak, weak")
    if not sys.platform.startswith("linux"):
        raise RuntimeError("Linux cleanup only runs on Linux.")
    root = install_dir()
    marker = root / ".installation"
    valid_markers = (_MARKER, _FLATPAK_MARKER, "PlusInPath Debian native installation v2\n")
    if not marker.exists():
        return {
            "process_stopped": False,
            "installation_removed": not root.exists(),
            "autostart_removed": not _autostart_file().exists(),
        }
    mark_text = marker.read_text(encoding="utf-8")
    if mark_text not in valid_markers:
        raise RuntimeError("The installation marker is unrecognized; nothing was removed.")
    stopped = _stop_engine(root)
    if mark_text == _FLATPAK_MARKER and shutil.which("flatpak"):
        subprocess.run(["flatpak", "uninstall", "--user", "-y", _FLATPAK_ID],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
    _unlink(_autostart_file())
    shutil.rmtree(str(root))
    return {
        "process_stopped": stopped,
        "installation_removed": not root.exists(),
        "autostart_removed": not _autostart_file().exists(),
    }
