import os
import sys
from pathlib import Path
from . import install_dir

binary = install_dir() / "LinEngine"
if not binary.is_file():
    binary = Path("/usr/bin/linengine")
if not binary.is_file():
    raise SystemExit("LinEngine is not installed. Run: python3 -c \"import PlusInPath; PlusInPath.setup('lindeb')\"")
os.execv(str(binary), [str(binary), *sys.argv[1:]])
